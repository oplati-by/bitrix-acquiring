<?
$MESS["LWO_CHATBOTS_UNSTEP_BEFORE"] 	 = "Модуль";
$MESS["LWO_CHATBOTS_UNSTEP_AFTER"]  	 = "удален";
$MESS["LWO_CHATBOTS_UNSTEP_SUBMIT_BACK"] = "Вернуться в список";