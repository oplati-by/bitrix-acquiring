<?
$MESS["LWO_CHATBOTS_STEP_BEFORE"] 	   = "Модуль";
$MESS["LWO_CHATBOTS_STEP_AFTER"]  	   = "установлен";
$MESS["LWO_CHATBOTS_STEP_SUBMIT_BACK"] = "Вернуться в список";