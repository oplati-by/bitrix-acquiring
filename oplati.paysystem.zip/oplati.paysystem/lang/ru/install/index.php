<?
$MESS['OPLATI_PAYSYSTEM_NAME'] = 'Оплати';
$MESS['OPLATI_PAYSYSTEM_MODULE_DESCRIPTION'] = 'Добавляет платежную систему "Оплати"';
$MESS['OPLATI_PAYSYSTEM_PARTNER_NAME'] = 'oplati';
$MESS["OPLATI_PAYSYSTEM_ERROR_VERSION"] = "Версия главного модуля ниже 14. Не поддерживается технология D7, необходимая модулю. Пожалуйста, обновите систему.";
$MESS["OPLATI_PAYSYSTEM_PARTNER_URI"] = "https://www.o-plati.by/";