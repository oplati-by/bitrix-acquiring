<?php

$MESS['OPLATI_PAYSYSTEM_RESTORE_SETTING'] = 'Настройки по умолчанию восстановлены!';
$MESS['OPLATI_PAYSYSTEM_NOT_SELECT'] = 'Не выбрано';

$MESS['OPLATI_PAYSYSTEM_PAYMENT_CONFIRM_TIME'] = 'Время ожидания подтверждения платежа (сек):';
$MESS['OPLATI_PAYSYSTEM_URL'] = 'Какой контур использовать:';
$MESS['OPLATI_PAYSYSTEM_URL_PROD'] = 'Промышленный';
$MESS['OPLATI_PAYSYSTEM_URL_TEST'] = 'Тестовый';
$MESS['OPLATI_PAYSYSTEM_CASHBOX_REGNUM'] = 'Регистрационный номер кассы:';
$MESS['OPLATI_PAYSYSTEM_PASSWORD'] = 'Пароль:';
$MESS['OPLATI_PAYSYSTEM_PUBLIC_KEY'] = 'Cекретный ключ интернет-кассы:';
$MESS['OPLATI_PAYSYSTEM_METHOD_REQUEST'] = 'Какой метод используем для отправки запросов:';
$MESS['OPLATI_PAYSYSTEM_METHOD_REQUEST_HTTP'] = 'Вitrix HttpClient';
$MESS['OPLATI_PAYSYSTEM_METHOD_REQUEST_CURL'] = 'Curl';
$MESS['OPLATI_PAYSYSTEM_TYPE_PAY'] = 'Каким образом вызываем оплату';
$MESS['OPLATI_PAYSYSTEM_TYPE_PAY_BUTTON'] = 'Нажатие на кнопку';
$MESS['OPLATI_PAYSYSTEM_TYPE_PAY_AUTO'] = 'Автопереход в платежный сервис';
$MESS['OPLATI_PAYSYSTEM_LOGO'] = 'Какой цвет логотипа использовать для оплаты: ';
$MESS['OPLATI_PAYSYSTEM_LOGO_BLACK'] = 'Черный';
$MESS['OPLATI_PAYSYSTEM_LOGO_WHITE'] = 'Белый';
$MESS['OPLATI_PAYSYSTEM_EMAILS_FOR_NOTIFICATIONS'] = 'Список почтовых ящиков для отправки уведомления об ошибке сверки с онлайн кассой (через запятую):';
$MESS['OPLATI_PAYSYSTEM_SET_LOGGING'] = 'Включить логирование запросов?';
$MESS['OPLATI_PAYSYSTEM_SET_SYNC_RECONCILIATION'] = 'Cверять итоги по смене с платежной системой "Оплати"(каждый день после 00:01)';

