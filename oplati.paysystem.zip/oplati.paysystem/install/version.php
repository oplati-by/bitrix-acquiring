<?php

$arModuleVersion = array(
  "VERSION" => "2.0.0",
  "VERSION_DATE" => "2025-03-30 12:00:00"
);
